package com.example.myportfolio_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
