import 'package:flutter/material.dart';
import 'package:myportfolio_app/more/variables.dart';

class Achievements extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (constraints.maxWidth <= 700) {
            return MobilePage();
          } else {
            return WebPage();
          }
        }
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_back, size: 43, color: Color(mainColor)),
        tooltip: 'Back',
        backgroundColor: Colors.white,
        onPressed: () {
          Navigator.pop(context);
        }
      )
    );
  }
}

class MobilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(12), 
            child: achieveContent
          )
        ),
      ) 
    );
  }
}

class WebPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(top: 12, left: 90, right: 90, bottom: 12), 
            child: achieveContent
          )
        ),
      ) 
    );
  }
}

final achieveContent = Column(
  crossAxisAlignment: CrossAxisAlignment.stretch,
  children: <Widget>[
    Padding(
      padding: EdgeInsets.only(top: 28, bottom: 22),
      child: Text(
        'Achievements',
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 46, 
          fontWeight: FontWeight.w400
        ),
      )
    ),
    Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8)
      ),
      child: Padding(
        padding: EdgeInsets.all(20),                     
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(bottom: 22),
              child: Text(
                'Competition', 
                style: TextStyle(fontSize: 23),
              ),
            ),
            competition,
            Padding(
              padding: EdgeInsets.only(bottom: 22, top: 30),
              child: Text(
                'Certificate', 
                style: TextStyle(fontSize: 23),
              ),
            ),
            certificate
          ],
        )
      ) 
    ),
    SizedBox(height: 47)
  ],
);

final competition = Column(
  children: <Widget>[
    Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(right: 14),
          child: Text('🏆', style: TextStyle(fontSize: 24)),    
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: 18),
            child: Text(
              '2nd Place at Vocational School in Software Engineering Quiz Competition (2018)', 
              style: TextStyle(fontSize: 19),
            ),
          ),
        ),
      ]
    ),
    Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(right: 14),
          child: Text('🏆', style: TextStyle(fontSize: 24)),    
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: 18),
            child: Text(
              '3rd Place at Vocational School in Blog Competition (2018)', 
              style: TextStyle(fontSize: 19),
            ),
          ),
        ),
      ]
    ),
  ]
);

final certificate = Column(
  children: <Widget>[
    Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(right: 14),
          child: Text('🏅', style: TextStyle(fontSize: 24)),    
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: 18),
            child: Text(
              'Certificate of Competence in Programming and Software Development with qualification as Junior Web Developer (LSP Computer / BNSP)', 
              style: TextStyle(fontSize: 19),
            ),
          ),
        ),
      ]
    ),
    Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(right: 14),
          child: Text('🏅', style: TextStyle(fontSize: 24)),    
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: 18),
            child: Text(
              'Certificate of Training at Digital Talent Scholarship in Web Developer organized by Kemkominfo (2020)', 
              style: TextStyle(fontSize: 19),
            ),
          ),
        ),
      ]
    ),
    Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(right: 14),
          child: Text('🏅', style: TextStyle(fontSize: 24)),    
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: 18),
            child: Text(
              'Certificate of Graduation at Dicoding in Basic of Web Programming (2019)', 
              style: TextStyle(fontSize: 19),
            ),
          ),
        ),
      ]
    ),
  ]
);

