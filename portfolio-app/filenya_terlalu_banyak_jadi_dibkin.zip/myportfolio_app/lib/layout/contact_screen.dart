import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:myportfolio_app/more/variables.dart';

class Contact extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (constraints.maxWidth <= 700) {
            return MobilePage();
          } else {
            return WebPage();
          }
        }
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_back, size: 43, color: Color(mainColor)),
        tooltip: 'Back',
        backgroundColor: Colors.white,
        onPressed: () {
          Navigator.pop(context);
        }
      )
    );
  }
}


class MobilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(12), 
            child: contactContent
          )
        ),
      ) 
    );
  }
}

class WebPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(top: 12, left: 90, right: 90, bottom: 12), 
            child: contactContent
          )
        ),
      ) 
    );
  }
}

final contactContent = Column(
  crossAxisAlignment: CrossAxisAlignment.stretch,
  children: <Widget>[
    Padding(
      padding: EdgeInsets.only(top: 28, bottom: 22),
      child: Text(
        'Contact',
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 46, 
          fontWeight: FontWeight.w400
        ),
      )
    ),
    Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8)
      ),
      child: Padding(
        padding: EdgeInsets.all(20),                     
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Image.asset('assets/images/telegram.png')
                  ),
                  InkWell(
                    child: Text('t.me/rizallk87', style: linkStyle),
                    onTap: () => launch('https://t.me/rizallk87/')
                  ) 
                ]
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Image.asset('assets/images/facebook.png')
                  ),
                  InkWell(
                    child: Text('facebook.com/rizall.kadamong.1', style: linkStyle),
                    onTap: () => launch('https://www.facebook.com/rizall.kadamong.1/')
                  ) 
                ]
              )
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Image.asset('assets/images/instagram.png')
                  ),
                  InkWell(
                    child: Text('instagram.com/rzll.kadamong21', style: linkStyle),
                    onTap: () => launch('https://www.instagram.com/rzll.kadamong21/')
                  ) 
                ]
              )
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Image.asset('assets/images/linkedin.png')
                  ),
                  InkWell(
                    child: Text('linkedin.com/in/rizall-kadamong', style: linkStyle),
                    onTap: () => launch('https://www.linkedin.com/in/rizall-kadamong/')
                  ) 
                ]
              )
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Row(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Image.asset('assets/images/github.png')
                  ),
                  InkWell(
                    child: Text('github.com/rizallk', style: linkStyle),
                    onTap: () => launch('https://github.com/rizallk/')
                  )
                ]
              )
            )
          ],
        )
      ) 
    ),
    SizedBox(height: 47)
  ],
);

final linkStyle = TextStyle(
  fontSize: 16,
  color: Color(mainColor),
  decorationColor: Color(mainColor),
  decoration: TextDecoration.underline,
);