import 'package:flutter/material.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:myportfolio_app/layout/menu_screen.dart';
import 'package:myportfolio_app/more/variables.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (constraints.maxWidth <= 900) {
            return MobilePage();
          } else {
            return WebPage();
          }
        }
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.menu, size: 43, color: Color(mainColor)),
        tooltip: 'Menu',
        backgroundColor: Colors.white,
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return Menu();
          }));
        }
      ),
    );
  }
}


class MobilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                logo,
                title,
                typeWriter,
                sosmed,
                foto,
                SizedBox(height: 55)
              ]
            ),
          )
        ),
      ) 
    );
  }
}

class WebPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(top: 65),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 3,
                  child: Column(
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Image.asset('assets/images/logo.png', height: 77),
                          Padding(
                            padding: EdgeInsets.only(top: 27),
                            child: titleWeb,               
                          ),
                        ]
                      ),
                      typeWriter,
                      sosmed
                    ]
                  )
                ),
                Expanded(
                  flex: 2,
                  child: fotoWeb
                )
              ]
            )
          )
        ),
      ) 
    );
  }
}

final logo = Padding(
  padding: EdgeInsets.only(top: 20, bottom: 40),
  child: Image.asset('assets/images/logo.png', height: 86,),
);

final title = Padding(
  padding: EdgeInsets.only(bottom: 20),
  child: Text(
    'Rizall Kadamong', 
    textAlign: TextAlign.center,
    style: TextStyle(
      fontSize: 60,
      color: Color(0xff4c657c),
      fontWeight: FontWeight.bold,
      height: 1.2
    )
  )
);

final titleWeb = Text(
  'Rizall Kadamong', 
  style: TextStyle(
  fontSize: 56,
    color: Color(0xff4c657c),
    fontWeight: FontWeight.bold,
  )
);

final typeWriter = SizedBox(
  height: 75,
  child: Center(
    child: AnimatedTextKit(
      animatedTexts: [
        TypewriterAnimatedText(
          'Hi!',
          textAlign: TextAlign.center,
          textStyle: TextStyle(
            fontSize: 28,
            color: Color(0xff101a2d),
            height: 1.2
          ),
          speed: Duration(milliseconds: 110),
          cursor: '|'
        ),
        TypewriterAnimatedText(
          'Welcome to my Portfolio App.',
          textAlign: TextAlign.center,
          textStyle: TextStyle(
            fontSize: 28,
            color: Color(0xff101a2d),
            height: 1.2
          ),
          speed: Duration(milliseconds: 110),
          cursor: '|'
        ),
        TypewriterAnimatedText(
          'I love Coding.',
          textAlign: TextAlign.center,
          textStyle: TextStyle(
            fontSize: 28,
            color: Color(0xff101a2d),
            height: 1.2
          ),
          speed: Duration(milliseconds: 110),
          cursor: '|'
        ),
        TypewriterAnimatedText(
          'I love Designing.',
          textAlign: TextAlign.center,
          textStyle: TextStyle(
            fontSize: 28,
            color: Color(0xff101a2d),
            height: 1.2
          ),
          speed: Duration(milliseconds: 110),
          cursor: '|'
        ),
        TypewriterAnimatedText(
          'And listening to Lo-Fi Music.',
          textAlign: TextAlign.center,
          textStyle: TextStyle(
            fontSize: 28,
            color: Color(0xff101a2d),
            height: 1.2
          ),
          speed: Duration(milliseconds: 110),
          cursor: '|'
        ),
      ],
      repeatForever: true,
      pause: Duration(milliseconds: 2700),
      displayFullTextOnTap: true,
      stopPauseOnTap: true,
    ),
  ),
);

final sosmed = Column(
  children: <Widget>[
    Padding(
      padding: EdgeInsets.only(top: 55, bottom: 8),
      child: Text(
        'Find me!',
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 23,
          color: Color(0xff2b2b2b),
          fontWeight: FontWeight.w600
        ),
      ),
    ),
    Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(right: 8),
          child: InkWell(
            child: Image.asset('assets/images/facebook.png'),
            onTap: () => launch('https://www.facebook.com/rizall.kadamong.1/')
          )
        ),
        Padding(
          padding: EdgeInsets.only(right: 8),
          child: InkWell(
            child: Image.asset('assets/images/instagram.png'),
            onTap: () => launch('https://www.instagram.com/rzll.kadamong21/')
          )
        ),
        Padding(
          padding: EdgeInsets.only(right: 8),
          child: InkWell(
            child: Image.asset('assets/images/github.png'),
            onTap: () => launch('https://github.com/rizallk/')
          )
        ),
        InkWell(
          child: Image.asset('assets/images/linkedin.png'),
          onTap: () => launch('https://www.linkedin.com/in/rizall-kadamong/')
        )
      ]
    )
  ]
);

final foto = Padding(
  padding: EdgeInsets.only(top: 55),
  child: Center(
    child: Container(
      width: 343,
      child: Stack(
        children: <Widget>[
          Positioned(
            right: 0,
            child: Image.asset('assets/images/design1.png'),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(top: 20, bottom: 15.5),
              child: Image.asset('assets/images/foto.png'), 
            )
          ),
          Positioned(
            bottom: 0,
            left: 0,
            child: Image.asset('assets/images/design2.png'),
          )
        ],
      ),
    )
  )
);

final fotoWeb = Center(
  child: Container(
    width: 343,
    child: Stack(
      children: <Widget>[
        Positioned(
          right: 0,
          child: Image.asset('assets/images/design1.png'),
        ),
        Center(
          child: Padding(
            padding: EdgeInsets.only(top: 20, bottom: 15.5),
            child: Image.asset('assets/images/foto.png'), 
          )
        ),
        Positioned(
          bottom: 0,
          left: 0,
          child: Image.asset('assets/images/design2.png'),
        )
      ],
    ),
  )
);

