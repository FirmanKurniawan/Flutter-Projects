import 'package:flutter/material.dart';
import 'package:myportfolio_app/more/variables.dart';

import 'package:myportfolio_app/layout/achieve_screen.dart';
import 'package:myportfolio_app/layout/projects_screen.dart';
import 'package:myportfolio_app/layout/skills_screen.dart';
import 'package:myportfolio_app/layout/contact_screen.dart';

class Menu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: <Widget>[
              SizedBox(height: 220),
              InkWell(
                child: Container(
                  margin: EdgeInsets.only(bottom: 20),
                  child: Text('Achievements', style: menuStyle),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Achievements();
                  }));
                },
              ),
              InkWell(
                child: Container(
                  margin: EdgeInsets.only(bottom: 20),
                  child: Text('Projects', style: menuStyle),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Projects();
                  }));
                },
              ),
              InkWell(
                child: Container(
                  margin: EdgeInsets.only(bottom: 20),
                  child: Text('Skills', style: menuStyle),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Skills();
                  }));
                },
              ),
              InkWell(
                child: Text('Contact', style: menuStyle),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Contact();
                  }));
                },
              ),
            ],
          )
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.home, size: 43, color: Color(mainColor)),
        tooltip: 'Home',
        backgroundColor: Colors.white,
        onPressed: () {
          Navigator.pop(context);
        }
      ),
    ); 
  }
}

final menuStyle = TextStyle(
  fontSize: 30,
  color: Color(darkColor),
  decorationColor: Color(mainColor),
  decoration: TextDecoration.underline,
  decorationThickness: 1.8
);