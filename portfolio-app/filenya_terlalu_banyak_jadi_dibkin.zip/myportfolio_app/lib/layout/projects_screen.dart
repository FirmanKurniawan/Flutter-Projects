import 'package:flutter/material.dart';
import 'package:myportfolio_app/more/variables.dart';

class Projects extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (constraints.maxWidth <= 600) {
            return ProjectsContent(gridCount: 1);
          } else if (constraints.maxWidth <= 800) {
            return ProjectsContent(gridCount: 2);
          } else if (constraints.maxWidth <= 1100) {
            return ProjectsContent(gridCount: 3);
          } else {
            return ProjectsContent(gridCount: 4);
          }
        }
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_back, size: 43, color: Color(mainColor)),
        tooltip: 'Back',
        backgroundColor: Colors.white,
        onPressed: () {
          Navigator.pop(context);
        }
      )
    );
  }
}

class ProjectsContent extends StatelessWidget {
  final int gridCount;

  ProjectsContent({required this.gridCount});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Scrollbar(
            isAlwaysShown: true,
            child: Padding(
              padding: EdgeInsets.all(12), 
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 28, bottom: 22),
                    child: Text(
                      'Projects',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 46, 
                        fontWeight: FontWeight.w400
                      ),
                    )
                  ),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: gridCount,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      children: <Widget>[
                        /** Zall Panel **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start, 
                            children: <Widget>[
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: borderImage, 
                                  child: Image.asset('assets/projects/webadmin.png', fit: BoxFit.cover),
                                )
                              ),
                              Padding(
                                padding: EdgeInsets.all(16),                     
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text('Zall Panel', style: titleStyle),
                                          FavoriteButton()
                                        ]
                                      )
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: Text('Dashboard Admin Template', style: descStyle),
                                    ),
                                    Wrap(
                                      children: <Widget>[
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('HTML5', style: techStyle),
                                        ),
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('CSS3', style: techStyle),
                                        ),
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('Javascript', style: techStyle),
                                        ),
                                        Container(
                                          padding: techPadding, decoration: techDecor,
                                          child: Text('SASS', style: techStyle),
                                        ),
                                      ]
                                    )
                                  ],
                                )
                              )
                            ]
                          ),
                        ),
                        
                        /** Company Profile **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: borderImage, 
                                  child: Image.asset('assets/projects/webcompany.png', fit: BoxFit.cover),
                                )  
                              ),
                              Padding(
                                padding: EdgeInsets.all(16),                     
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text('Company Profile', style: titleStyle),
                                          FavoriteButton()
                                        ]
                                      )
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: Text('Company Profile Template', style: descStyle),
                                    ),
                                    Wrap(
                                      children: <Widget>[
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('Bootstrap 5', style: techStyle),
                                        ),
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('Javascript', style: techStyle),
                                        ),
                                        Container(
                                          padding: techPadding, decoration: techDecor,
                                          child: Text('SASS', style: techStyle),
                                        ),
                                      ]
                                    )
                                  ],
                                )
                              )
                            ]
                          ),
                        ),
                        
                        /** Inventaris Sekolah **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: borderImage, 
                                  child: Image.asset('assets/projects/webinven.png', fit: BoxFit.cover),
                                )
                              ),
                              Padding(
                                padding: EdgeInsets.all(16),                     
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text('Inventaris Sekolah', style: titleStyle),
                                          FavoriteButton()
                                        ]
                                      )
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: Text('Website Inventaris Aset Sekolah', style: descStyle),
                                    ),
                                    Wrap(
                                      children: <Widget>[
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('PHP Native', style: techStyle),
                                        ),
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('Bootstrap 4', style: techStyle),
                                        ),
                                        Container(
                                          padding: techPadding, decoration: techDecor,
                                          child: Text('Javascript', style: techStyle),
                                        ),
                                      ]
                                    )
                                  ],
                                )
                              )
                            ]
                          ),
                        ),

                        /** Evoting **/
                        Card(
                          margin: EdgeInsets.only(bottom: 20),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: borderImage, 
                                  child: Image.asset('assets/projects/webevote.jpg', fit: BoxFit.cover),
                                )
                              ),
                              Padding(
                                padding: EdgeInsets.all(16),                     
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text('E-Voting', style: titleStyle),
                                          FavoriteButton()
                                        ]
                                      )
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: Text('Website E-Voting for OSIS', style: descStyle),
                                    ),
                                    Wrap(
                                      children: <Widget>[
                                      Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('CodeIgniter 3', style: techStyle),
                                        ),
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('Bootstrap 4', style: techStyle),
                                        ),
                                        Container(
                                          padding: techPadding, decoration: techDecor,
                                          child: Text('Javascript', style: techStyle),
                                        ),
                                      ]
                                    )
                                  ],
                                )
                              )
                            ]
                          ),
                        ),
                        
                        /** Sertifikasi **/
                        Card(
                          margin: EdgeInsets.only(bottom: 20),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: borderImage, 
                                  child: Image.asset('assets/projects/websertifikasi.png', fit: BoxFit.cover),
                                )
                              ),
                              Padding(
                                padding: EdgeInsets.all(16),                     
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 8),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text('Aplikasi Sertifikasi', style: titleStyle),
                                          FavoriteButton()
                                        ]
                                      )
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 16),
                                      child: Text('Website Sertifikasi (BNSP)', style: descStyle),
                                    ),
                                    Wrap(
                                      children: <Widget>[
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('CodeIgniter 4', style: techStyle),
                                        ),
                                        Container(
                                          margin: techMargin, padding: techPadding, decoration: techDecor,
                                          child: Text('Bootstrap 4', style: techStyle),
                                        ),
                                        Container(
                                          padding: techPadding, decoration: techDecor,
                                          child: Text('JQuery', style: techStyle),
                                        ),
                                      ]
                                    )
                                  ],
                                )
                              )
                            ]
                          ),
                        ),

                      ]
                    ) 
                  ),
                  SizedBox(height: 27)
                ],
              )
            )
          ),
        ) ,
    );
  }
}

class FavoriteButton extends StatefulWidget {
  @override
  _FavoriteButtonState createState() => _FavoriteButtonState();
}
 
class _FavoriteButtonState extends State<FavoriteButton> {
  bool isFavorite = false;
 
  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(
        isFavorite ? Icons.favorite : Icons.favorite_border,
        color: Colors.red,
      ),
      onPressed: () {
        setState(() {
          isFavorite = !isFavorite;
        });
      },
    );
  }
}


final borderImage = BorderRadius.only(topLeft: Radius.circular(8), topRight: Radius.circular(8));
final titleStyle = TextStyle(fontSize: 20, fontWeight: FontWeight.w500);
final descStyle = TextStyle(fontSize: 16, color: Color(0xff707070));
final techStyle = TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600);
final techPadding = EdgeInsets.only(top: 2, bottom: 2, left: 6, right: 6);
final techMargin = EdgeInsets.only(right: 5);
final techDecor = BoxDecoration(borderRadius: BorderRadius.circular(2.5), color: Color(mainColor));