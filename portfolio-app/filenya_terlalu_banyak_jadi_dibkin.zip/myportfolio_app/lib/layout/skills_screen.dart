import 'package:flutter/material.dart';
import 'package:myportfolio_app/more/variables.dart';

class Skills extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (constraints.maxWidth <= 600) {
            return SkillsContent(gridCount: 1);
          } else if (constraints.maxWidth <= 891) {
            return SkillsContent(gridCount: 2);
          } else if (constraints.maxWidth <= 1186) {
            return SkillsContent(gridCount: 3);
          } else {
            return SkillsContent(gridCount: 4);
          }
        }
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.arrow_back, size: 43, color: Color(mainColor)),
        tooltip: 'Back',
        backgroundColor: Colors.white,
        onPressed: () {
          Navigator.pop(context);
        }
      )
    );
  }
}

class SkillsContent extends StatelessWidget {
  final int gridCount;

  SkillsContent({required this.gridCount});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Scrollbar(
            isAlwaysShown: true,
            child: Padding(
              padding: EdgeInsets.all(12), 
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 28, bottom: 22),
                    child: Text(
                      'Skills',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 46, 
                        fontWeight: FontWeight.w400
                      ),
                    )
                  ),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: gridCount,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      children: <Widget>[
                        /** SASS **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/sass.png', height: 140),
                              ),
                              Text('SASS', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '7 months', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),
                        
                        /** JQuery **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/jquery.png', height: 140),
                              ),
                              Text('JQuery', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '2 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                        /** CodeIgniter **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/codeigniter.png', height: 140),
                              ),
                              Text('CodeIgniter', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '3 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                        /** Bootstrap **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/bootstrap.png', height: 140),
                              ),
                              Text('Bootstrap', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '3 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                        /** MySQL **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/mysql.png', height: 140),
                              ),
                              Text('MySQL / MariaDB', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '3 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                        /** JS **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/js.png', height: 140),
                              ),
                              Text('JavaScript', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '3 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                        /** CSS **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/css.png', height: 140),
                              ),
                              Text('CSS', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '3 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                        /** PHP **/
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center, 
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 26, bottom: 18),
                                child: Image.asset('assets/skills/php.png', height: 140),
                              ),
                              Text('PHP', style: titleStyle),
                              Padding(
                                padding: EdgeInsets.only(top: 5, bottom: 15),
                                child: Text.rich(
                                  TextSpan(text: '3 years', style: monthsStyle, children: <InlineSpan>[experience])
                                )
                              )
                            ]
                          ),
                        ),

                      ]
                    )
                  ),
                  SizedBox(height: 27)
                ],
              )
            )
          ),
        ),
    );
  }
}


final titleStyle = TextStyle(fontSize: 20, fontWeight: FontWeight.w600);
final monthsStyle = TextStyle(color: Color(mainColor), fontSize: 16, fontWeight: FontWeight.w600);
final experience = TextSpan(
  text: ' of experience', 
  style: TextStyle(
    color: Color(darkColor), 
    fontWeight: FontWeight.normal
  )
);