// import 'package:flutter/material.dart';

// List projects = [
//   {
//     'nama': 'Zall Panel',
//     'desc': 'Dashboard Admin Template',
//     'image': 'assets/projects/webadmin.png',
//     'tech': [
//       'HTML5',
//       'CSS3',
//       'Javascript',
//       'SASS'
//     ],
//   },
//   {
//     'nama': 'Zall Panel',
//     'desc': 'Dashboard Admin Template',
//     'image': 'assets/projects/webadmin.png',
//     'tech': [
//       'HTML5',
//       'CSS3',
//       'Javascript',
//       'SASS'
//     ],
//   },
// ];

// List test = [
//   ['zall panel', 'anjay mabar'],
// ];

// class ProjectsModel {
//   String name, description, image;
//   List<String> technology;

//   ProjectsModel({
//     required this.name,
//     required this.description,
//     required this.image,
//     required this.technology,
//   });
// }

// var projectsModelList = [
//   ProjectsModel(
//     name: 'Zall Panel',
//     description: 'Dashboard Admin Template',
//     image: 'assets/projects/webadmin.png',
//     technology: [
//       'HTML5',
//       'CSS3',
//       'Javascript',
//       'SASS',
//     ]
//   )
// ];

// class Testing extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Testing')),
//       body: Padding(
//         padding: EdgeInsets.all(20),
//         child: Column(
//           children: <Widget>[
//             anjay
//           ]
//         )
//       ),
//     );
//   }
// }

