final mainColor = 0xff0bb784; // Warna utama
final darkColor = 0xff212529; // Dark